require('dotenv').config();
const {
    Client, GatewayIntentBits, Partials, Collection, EmbedBuilder,
    SlashCommandBuilder, REST, Routes, ActionRowBuilder, ButtonBuilder,
    ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType
} = require('discord.js');
const db = require('./db');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User],
});

// --- Command Definitions ---

const commands = [
    new SlashCommandBuilder()
        .setName('setup-panels')
        .setDescription('Post the UCP and Ticket panels to designated channels (Admin Only)'),

    new SlashCommandBuilder()
        .setName('broadcast')
        .setDescription('Broadcast server status or IP (Admin Only)')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Type of broadcast')
                .setRequired(true)
                .addChoices(
                    { name: 'Server ON', value: 'server_on' },
                    { name: 'Server OFF', value: 'server_off' },
                    { name: 'Server IP', value: 'server_ip' }
                )),

    new SlashCommandBuilder()
        .setName('setadmin')
        .setDescription('Set admin level for a character (Admin Only)')
        .addStringOption(option =>
            option.setName('charname')
                .setDescription('The name of the character (e.g., First_Last)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('level')
                .setDescription('Admin level (0-7)')
                .setRequired(true)),

    new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Check player character statistics')
        .addStringOption(option =>
            option.setName('charname')
                .setDescription('The name of the character')
                .setRequired(true)),
];

// --- Registration Logic ---

async function registerCommands() {
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
}

// --- Helper Functions ---

async function sendUCPInfo(status) {
    const channel = await client.channels.fetch(process.env.UCP_INFO_CH);
    if (!channel) return;
    const embed = new EmbedBuilder()
        .setTitle('UCP System Status')
        .setColor(status === 'online' ? 0x00FF00 : 0xFF0000)
        .setDescription(`Sistem UCP saat ini sedang **${status.toUpperCase()}**.\n${status === 'online' ? 'Silahkan gunakan panel untuk mendaftar atau cek login.' : 'Harap tunggu hingga sistem kembali online.'}`)
        .setTimestamp();
    await channel.send({ embeds: [embed] });
}

// --- Event Handlers ---

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    await registerCommands();
    await sendUCPInfo('online');
});

client.on('interactionCreate', async interaction => {
    // Handling Slash Commands
    if (interaction.isChatInputCommand()) {
        const { commandName, options, member } = interaction;

        // Admin Check Middleware
        const isAdmin = member.roles.cache.has(process.env.ADMIN_ROLE_ID);

        if (commandName === 'setup-panels') {
            if (!isAdmin) return interaction.reply({ content: 'Akses ditolak!', ephemeral: true });

            // UCP Panel
            const ucpChannel = await client.channels.fetch(process.env.UCP_PANEL_CH);
            if (ucpChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Nusantara Life Roleplay - UCP Panel')
                    .setDescription('Silahkan pilih layanan di bawah ini:')
                    .setColor(0x0099FF)
                    .setFooter({ text: 'Kode verifikasi akan dikirimkan melalui DM' });

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('btn_register').setLabel('Daftar UCP').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('btn_login').setLabel('Cek Login').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('btn_reroll').setLabel('Reroll Karakter').setStyle(ButtonStyle.Danger)
                );
                await ucpChannel.send({ embeds: [embed], components: [row] });
            }

            // Ticket Panel
            const ticketChannel = await client.channels.fetch(process.env.TICKET_CH);
            if (ticketChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Laporan & Bantuan')
                    .setDescription('Klik tombol di bawah untuk melaporkan cheater atau masalah teknis lainnya.')
                    .setColor(0xFF0000);

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('btn_open_ticket').setLabel('Buka Tiket Laporan').setStyle(ButtonStyle.Danger)
                );
                await ticketChannel.send({ embeds: [embed], components: [row] });
            }

            return interaction.reply({ content: 'Panels have been setup successfully!', ephemeral: true });
        }

        if (commandName === 'broadcast') {
            if (!isAdmin) return interaction.reply({ content: 'Akses ditolak!', ephemeral: true });
            const type = options.getString('type');

            if (type === 'server_on' || type === 'server_off') {
                const ch = await client.channels.fetch(process.env.SERVER_STATUS_CH);
                const embed = new EmbedBuilder()
                    .setTitle('Server Information')
                    .setColor(type === 'server_on' ? 0x00FF00 : 0xFF0000)
                    .setDescription(`Server Nusantara Life Roleplay saat ini **${type === 'server_on' ? 'TELAH MENYALA' : 'SEDANG MATI'}**!`)
                    .setTimestamp();
                await ch.send({ embeds: [embed] });
            } else if (type === 'server_ip') {
                const ch = await client.channels.fetch(process.env.SERVER_IP_CH);
                const embed = new EmbedBuilder()
                    .setTitle('Server IP Address')
                    .setColor(0xFFFF00)
                    .addFields(
                        { name: 'Hostname', value: 'Nusantara Life Roleplay' },
                        { name: 'IP Address', value: `${process.env.SERVER_IP}:${process.env.SERVER_PORT}` }
                    )
                    .setThumbnail(client.user.displayAvatarURL());
                await ch.send({ embeds: [embed] });
            }
            return interaction.reply({ content: 'Broadcast sent!', ephemeral: true });
        }

        if (commandName === 'setadmin') {
            if (!isAdmin) return interaction.reply({ content: 'Akses ditolak!', ephemeral: true });
            const charName = options.getString('charname');
            const level = options.getInteger('level');

            try {
                const result = await db.query('UPDATE `player_characters` SET `Char_Admin` = ? WHERE `Char_Name` = ?', [level, charName]);
                if (result.affectedRows === 0) return interaction.reply({ content: 'Karakter tidak ditemukan!', ephemeral: true });
                await interaction.reply({ content: `Admin level \`${charName}\` diubah ke ${level}.` });
            } catch (e) {
                await interaction.reply({ content: 'Gagal update database.', ephemeral: true });
            }
        }

        if (commandName === 'stats') {
            const charName = options.getString('charname');
            try {
                const results = await db.query('SELECT * FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                if (results.length === 0) return interaction.reply({ content: `Karakter \`${charName}\` tidak ditemukan.`, ephemeral: true });

                const data = results[0];
                const embed = new EmbedBuilder()
                    .setTitle(`Stats: ${charName}`)
                    .setColor(0xFFA500)
                    .addFields(
                        { name: 'Level', value: `${data.Char_Level}`, inline: true },
                        { name: 'Money', value: `$${data.Char_Money}`, inline: true },
                        { name: 'Admin', value: `${data.Char_Admin}`, inline: true }
                    );
                await interaction.reply({ embeds: [embed] });
            } catch (e) {
                await interaction.reply({ content: 'Gagal mengambil stats.', ephemeral: true });
            }
        }
    }

    // Handling Buttons
    if (interaction.isButton()) {
        const { customId } = interaction;

        if (customId === 'btn_register') {
            const modal = new ModalBuilder().setCustomId('modal_register').setTitle('Pendaftaran UCP');
            const ucpInput = new TextInputBuilder().setCustomId('ucp_name').setLabel('Masukkan Nama UCP').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(ucpInput));
            await interaction.showModal(modal);
        }

        if (customId === 'btn_login') {
            const modal = new ModalBuilder().setCustomId('modal_login').setTitle('Cek Login UCP');
            const ucpInput = new TextInputBuilder().setCustomId('ucp_name').setLabel('Masukkan Nama UCP').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(ucpInput));
            await interaction.showModal(modal);
        }

        if (customId === 'btn_reroll') {
            const modal = new ModalBuilder().setCustomId('modal_reroll').setTitle('Reroll Karakter');
            const charInput = new TextInputBuilder().setCustomId('char_name').setLabel('Nama Karakter (First_Last)').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(charInput));
            await interaction.showModal(modal);
        }

        if (customId === 'btn_open_ticket') {
            const thread = await interaction.channel.threads.create({
                name: `tiket-${interaction.user.username}`,
                autoArchiveDuration: 60,
                type: InteractionType.GuildPublicThread, // Simplified for this implementation
                reason: 'Laporan User',
            });
            await thread.send({ content: `Halo <@${interaction.user.id}>, silahkan jelaskan laporanmu di sini. Staff <@&${process.env.ADMIN_ROLE_ID}> akan segera membantu.` });
            await interaction.reply({ content: `Tiket kamu telah dibuka di <#${thread.id}>`, ephemeral: true });
        }
    }

    // Handling Modals
    if (interaction.type === InteractionType.ModalSubmit) {
        const { customId, fields, user } = interaction;

        if (customId === 'modal_register') {
            const ucpName = fields.getTextInputValue('ucp_name');
            try {
                const existing = await db.query('SELECT * FROM `playerucp` WHERE `ucp` = ?', [ucpName]);
                if (existing.length > 0) return interaction.reply({ content: 'UCP sudah terdaftar!', ephemeral: true });

                const verifyCode = Math.floor(100000 + Math.random() * 900000);
                await db.query('INSERT INTO `playerucp` (`ucp`, `verifycode`, `DiscordID`) VALUES (?, ?, ?)', [ucpName, verifyCode, user.id]);

                await user.send({ content: `Pendaftaran Berhasil!\nUCP: **${ucpName}**\nKode Verifikasi: **${verifyCode}**\n\nGunakan kode ini saat login di server.` });
                await interaction.reply({ content: 'Pendaftaran berhasil! Cek DM kamu untuk kode verifikasi.', ephemeral: true });
            } catch (e) {
                await interaction.reply({ content: 'Error database.', ephemeral: true });
            }
        }

        if (customId === 'modal_login') {
            const ucpName = fields.getTextInputValue('ucp_name');
            try {
                const results = await db.query('SELECT `verifycode` FROM `playerucp` WHERE `ucp` = ?', [ucpName]);
                if (results.length === 0) return interaction.reply({ content: 'UCP tidak ditemukan!', ephemeral: true });

                await user.send({ content: `Informasi Login UCP: **${ucpName}**\nKode Verifikasi kamu: **${results[0].verifycode}**` });
                await interaction.reply({ content: 'Informasi telah dikirim ke DM kamu.', ephemeral: true });
            } catch (e) {
                await interaction.reply({ content: 'Error retrieving data.', ephemeral: true });
            }
        }

        if (customId === 'modal_reroll') {
            const charName = fields.getTextInputValue('char_name');
            try {
                const results = await db.query('SELECT * FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                if (results.length === 0) return interaction.reply({ content: 'Karakter tidak ditemukan!', ephemeral: true });

                await db.query('DELETE FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                await interaction.reply({ content: `Karakter \`${charName}\` berhasil di-reroll (dihapus). Silahkan buat karakter baru di in-game.`, ephemeral: true });
            } catch (e) {
                await interaction.reply({ content: 'Gagal reroll.', ephemeral: true });
            }
        }
    }
});

client.login(process.env.DISCORD_TOKEN);
