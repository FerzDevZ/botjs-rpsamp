#!/bin/bash
while true
do
	echo "Starting Nusantara Life Roleplay Discord Bot..."
	node index.js
	echo "Bot crashed or stopped. Restarting in 5 seconds..."
	sleep 5
done
