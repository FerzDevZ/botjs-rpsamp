require('dotenv').config();
const {
    Client, GatewayIntentBits, Partials, Collection, EmbedBuilder,
    SlashCommandBuilder, REST, Routes, ActionRowBuilder, ButtonBuilder,
    ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, ActivityType
} = require('discord.js');
const db = require('./db');
const dgram = require('dgram');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User],
});

// --- Command Definitions ---

const commands = [
    new SlashCommandBuilder()
        .setName('setup-panels')
        .setDescription('Post the UCP and Ticket panels to designated channels (Admin Only)'),

    new SlashCommandBuilder()
        .setName('broadcast')
        .setDescription('Broadcast server status or IP (Admin Only)')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Type of broadcast')
                .setRequired(true)
                .addChoices(
                    { name: 'Server ON', value: 'server_on' },
                    { name: 'Server OFF', value: 'server_off' },
                    { name: 'Server IP', value: 'server_ip' }
                )),

    new SlashCommandBuilder()
        .setName('setadmin')
        .setDescription('Set admin level for a character (Admin Only)')
        .addStringOption(option =>
            option.setName('charname')
                .setDescription('The name of the character (e.g., First_Last)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('level')
                .setDescription('Admin level (0-7)')
                .setRequired(true)),

    new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Check player character statistics')
        .addStringOption(option =>
            option.setName('charname')
                .setDescription('The name of the character')
                .setRequired(true)),

    new SlashCommandBuilder()
        .setName('me')
        .setDescription('Cek stats karakter kamu sendiri (Wajib sudah link Discord)'),

    new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('Lihat 10 pemain terkaya di server'),

    new SlashCommandBuilder()
        .setName('rules')
        .setDescription('Baca peraturan dasar server'),
];

// --- Registration Logic ---

async function registerCommands() {
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        if (error.code === 50001) {
            console.error('\n\n❌ ERROR FATAL: MISSING ACCESS (50001)');
            console.error('Bot tidak punya izin untuk membuat Slash Commands.');
            console.error('SOLUSI:');
            console.error('1. KICK bot dari server Discord.');
            console.error('2. Buka https://discord.com/developers/applications');
            console.error('3. Pilih OAuth2 > URL Generator.');
            console.error('4. Centang SCOPES: [bot] DAN [applications.commands] (Wajib!)');
            console.error('5. Invite ulang botnya.\n\n');
        } else {
            console.error(error);
        }
    }
}

// --- Helper Functions ---

async function sendUCPInfo(status) {
    const channel = await client.channels.fetch(process.env.UCP_INFO_CH);
    if (!channel) return;
    const embed = new EmbedBuilder()
        .setTitle('Nusantara Life Roleplay | UCP System')
        .setColor(status === 'online' ? 0x00FF00 : 0xFF0000)
        .setDescription(status === 'online'
            ? '✅ **SYSTEM ONLINE**\nLayanan UCP siap digunakan. Gunakan panel di bawah untuk manajemen akun.'
            : '❌ **SYSTEM OFFLINE**\nMohon maaf, layanan UCP sedang dalam perbaikan.')
        .setThumbnail(client.user.displayAvatarURL())
        .setTimestamp();

    // Check if last message is from bot to edit instead of spamming
    const trailingMessages = await channel.messages.fetch({ limit: 1 });
    const lastMessage = trailingMessages.first();
    if (lastMessage && lastMessage.author.id === client.user.id) {
        await lastMessage.edit({ embeds: [embed] });
    } else {
        await channel.send({ embeds: [embed] });
    }
}

function querySAMP(ip, port) {
    return new Promise((resolve, reject) => {
        const socket = dgram.createSocket('udp4');
        const timeout = setTimeout(() => {
            socket.close();
            reject(new Error('Query timeout'));
        }, 3000);

        const packet = Buffer.alloc(11);
        packet.write('SAMP', 0);
        packet[4] = 127; packet[5] = 0; packet[6] = 0; packet[7] = 1;
        packet[8] = port & 0xFF;
        packet[9] = (port >> 8) & 0xFF;
        packet[10] = 'i'.charCodeAt(0);

        socket.on('message', (msg) => {
            clearTimeout(timeout);
            socket.close();
            if (msg.length < 11) return reject(new Error('Invalid response'));
            const players = msg.readUInt16LE(12);
            const maxPlayers = msg.readUInt16LE(14);
            resolve({ players, maxPlayers });
        });

        socket.on('error', (err) => {
            clearTimeout(timeout);
            socket.close();
            reject(err);
        });

        socket.send(packet, 0, packet.length, port, ip);
    });
}

async function updatePlayerCount() {
    try {
        const ip = process.env.SERVER_IP || 'nusantaralrp.ddns.net';
        const port = parseInt(process.env.SERVER_PORT) || 3417;
        const data = await querySAMP(ip, port);
        client.user.setActivity(`${data.players}/${data.maxPlayers} Players Online`, { type: ActivityType.Playing });
    } catch (error) {
        console.error('Failed to update player count:', error.message);
        client.user.setActivity('Server Offline', { type: ActivityType.Watching });
    }
}

// --- Event Handlers ---

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);

    // DEBUG: Check Guilds
    console.log('📊 Current Guilds:', client.guilds.cache.map(g => `${g.name} (${g.id})`).join(', '));
    const targetGuild = client.guilds.cache.get(process.env.GUILD_ID);
    if (!targetGuild) {
        console.error(`\n❌ ERROR: Bot is NOT in the target Guild ID: ${process.env.GUILD_ID}`);
        console.error('Make sure you invited the bot to the correct server!\n');
    } else {
        console.log(`✅ Verified: Bot is present in target Guild: ${targetGuild.name}`);
        await registerCommands();
    }

    await sendUCPInfo('online');

    // Initial update
    updatePlayerCount();
    // Update every 30 seconds
    setInterval(updatePlayerCount, 30000);
});

client.on('interactionCreate', async interaction => {
    // Handling Slash Commands
    if (interaction.isChatInputCommand()) {
        const { commandName, options, member } = interaction;

        // Admin Check Middleware
        const isAdmin = member.roles.cache.has(process.env.ADMIN_ROLE_ID);

        if (commandName === 'setup-panels') {
            if (!isAdmin) return interaction.reply({ content: 'Akses ditolak!', ephemeral: true });

            // UCP Panel
            const ucpChannel = await client.channels.fetch(process.env.UCP_PANEL_CH);
            if (ucpChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('🔐 USER CONTROL PANEL (UCP)')
                    .setDescription('Selamat datang di **Nusantara Life Roleplay**.\nSilahkan gunakan menu di bawah untuk mengatur akun Anda.')
                    .setColor(0x2b2d31)
                    .addFields(
                        { name: '🆕 Member Baru', value: 'Klik **Daftar UCP** untuk membuat akun baru.', inline: true },
                        { name: '🔑 Lupa Password/Pin?', value: 'Klik **Cek Login** atau **Ganti Password**.', inline: true },
                        { name: '🗑️ Reset Karakter', value: 'Klik **Reroll** untuk menghapus karakter lama.', inline: false }
                    )
                    .setImage('https://media.discordapp.net/attachments/1182283437155688508/1182283597155803156/banner.png?ex=65e1b69f&is=65cf419f&hm=... (Place a valid banner URL here if needed)')
                    .setFooter({ text: 'Nusantara Life Roleplay Automatic System' });

                const row1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('btn_register').setLabel('📝 Daftar UCP').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('btn_login').setLabel('👀 Cek Info Login').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('btn_status').setLabel('👤 My Status').setStyle(ButtonStyle.Primary)
                );

                const row2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('btn_change_pw').setLabel('🔑 Ganti Password').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('btn_reroll').setLabel('💀 Reroll / Hapus Char').setStyle(ButtonStyle.Danger)
                );

                await ucpChannel.send({ embeds: [embed], components: [row1, row2] });
            }

            // Ticket Panel
            const ticketChannel = await client.channels.fetch(process.env.TICKET_CH);
            if (ticketChannel) {
                const embed = new EmbedBuilder()
                    .setTitle('Laporan & Bantuan')
                    .setDescription('Klik tombol di bawah untuk melaporkan cheater atau masalah teknis lainnya.')
                    .setColor(0xFF0000);

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('btn_open_ticket').setLabel('Buka Tiket Laporan').setStyle(ButtonStyle.Danger)
                );
                await ticketChannel.send({ embeds: [embed], components: [row] });
            }

            return interaction.reply({ content: 'Panel UCP & Ticket telah diperbarui!', ephemeral: true });
        }

        if (commandName === 'broadcast') {
            if (!isAdmin) return interaction.reply({ content: 'Akses ditolak!', ephemeral: true });
            const type = options.getString('type');

            if (type === 'server_on' || type === 'server_off') {
                const ch = await client.channels.fetch(process.env.SERVER_STATUS_CH);
                const embed = new EmbedBuilder()
                    .setTitle('Server Information')
                    .setColor(type === 'server_on' ? 0x00FF00 : 0xFF0000)
                    .setDescription(`Server Nusantara Life Roleplay saat ini **${type === 'server_on' ? 'TELAH MENYALA' : 'SEDANG MATI'}**!`)
                    .setTimestamp();
                await ch.send({ embeds: [embed] });
            } else if (type === 'server_ip') {
                const ch = await client.channels.fetch(process.env.SERVER_IP_CH);
                const embed = new EmbedBuilder()
                    .setTitle('Server IP Address')
                    .setColor(0xFFFF00)
                    .addFields(
                        { name: 'Hostname', value: 'Nusantara Life Roleplay' },
                        { name: 'IP Address', value: `${process.env.SERVER_IP}:${process.env.SERVER_PORT}` }
                    )
                    .setThumbnail(client.user.displayAvatarURL());
                await ch.send({ embeds: [embed] });
            }
            return interaction.reply({ content: 'Broadcast sent!', ephemeral: true });
        }

        if (commandName === 'setadmin') {
            if (!isAdmin) return interaction.reply({ content: 'Akses ditolak!', ephemeral: true });
            const charName = options.getString('charname');
            const level = options.getInteger('level');

            try {
                const result = await db.query('UPDATE `player_characters` SET `Char_Admin` = ? WHERE `Char_Name` = ?', [level, charName]);
                if (result.affectedRows === 0) return interaction.reply({ content: 'Karakter tidak ditemukan!', ephemeral: true });
                await interaction.reply({ content: `Admin level \`${charName}\` diubah ke ${level}.` });
            } catch (e) {
                await interaction.reply({ content: 'Gagal update database.', ephemeral: true });
            }
        }

        if (commandName === 'stats') {
            const charName = options.getString('charname');
            try {
                const results = await db.query('SELECT * FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                if (results.length === 0) return interaction.reply({ content: `Karakter \`${charName}\` tidak ditemukan.`, ephemeral: true });

                const data = results[0];
                const embed = new EmbedBuilder()
                    .setTitle(`Stats: ${charName}`)
                    .setColor(0xFFA500)
                    .addFields(
                        { name: 'Level', value: `${data.Char_Level}`, inline: true },
                        { name: 'Money', value: `$${data.Char_Money}`, inline: true },
                        { name: 'Admin', value: `${data.Char_Admin}`, inline: true }
                    );
                await interaction.reply({ embeds: [embed] });
            } catch (e) {
                await interaction.reply({ content: 'Gagal mengambil stats.', ephemeral: true });
            }
        }

        if (commandName === 'me') {
            try {
                // Find UCP linked to Discord ID
                const ucpRes = await db.query('SELECT `ucp` FROM `playerucp` WHERE `DiscordID` = ?', [member.id]);
                if (ucpRes.length === 0) return interaction.reply({ content: '❌ Kamu belum mendaftar UCP! Silahkan daftar di channel UCP.', ephemeral: true });

                const ucpName = ucpRes[0].ucp;
                const charRes = await db.query('SELECT * FROM `player_characters` WHERE `Char_UCP` = ? LIMIT 1', [ucpName]); // Show main char

                if (charRes.length === 0) return interaction.reply({ content: `✅ UCP: **${ucpName}** terdaftar, tapi belum ada karakter. Login ingame untuk buat karakter!`, ephemeral: true });

                const char = charRes[0];
                const embed = new EmbedBuilder()
                    .setTitle(`👤 Character Info: ${char.Char_Name}`)
                    .setColor(0x00AAFF)
                    .setThumbnail(member.user.displayAvatarURL())
                    .addFields(
                        { name: 'UCP Account', value: `\`${ucpName}\``, inline: true },
                        { name: 'Level', value: `\`${char.Char_Level}\``, inline: true },
                        { name: 'Money', value: `\`$${char.Char_Money}\``, inline: true },
                        { name: 'Last Login', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: false } // Placeholder for actual last login if available
                    );

                await interaction.reply({ embeds: [embed] });
            } catch (e) {
                console.error(e);
                await interaction.reply({ content: 'Error mengambil data.', ephemeral: true });
            }
        }

        if (commandName === 'leaderboard') {
            try {
                const res = await db.query('SELECT `Char_Name`, `Char_Money` FROM `player_characters` ORDER BY `Char_Money` DESC LIMIT 10');
                const list = res.map((p, i) => `**#${i + 1}** ${p.Char_Name} - 💲${p.Char_Money}`).join('\n');

                const embed = new EmbedBuilder()
                    .setTitle('🏆 Top 10 Richest Players')
                    .setColor(0xFFD700)
                    .setDescription(list || 'Belum ada data.');

                await interaction.reply({ embeds: [embed] });
            } catch (e) {
                await interaction.reply({ content: 'Gagal memuat leaderboard.', ephemeral: true });
            }
        }

        if (commandName === 'rules') {
            const embed = new EmbedBuilder()
                .setTitle('📜 Server Rules (Singkat)')
                .setColor(0xFFFFFF)
                .setDescription('1. **Dilarang Cheating/Hacking** (Ban Permanen)\n2. **Hormati Player Lain** (No SARA/Toxic)\n3. **Metagaming & Powergaming** Dilarang keras.\n4. **Roleplay Properly**: Gunakan /me dan /do dengan benar.\n\n*Baca rules lengkap di channel #rules*');
            await interaction.reply({ embeds: [embed] });
        }
    }

    // Handling Buttons
    if (interaction.isButton()) {
        const { customId } = interaction;

        if (customId === 'btn_register') {
            const modal = new ModalBuilder().setCustomId('modal_register').setTitle('Pendaftaran UCP Baru');
            const ucpInput = new TextInputBuilder().setCustomId('ucp_name').setLabel('Nama UCP (Tanpa Spasi)').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(ucpInput));
            await interaction.showModal(modal);
        }

        if (customId === 'btn_login') {
            const modal = new ModalBuilder().setCustomId('modal_login').setTitle('Cek Informasi Login');
            const ucpInput = new TextInputBuilder().setCustomId('ucp_name').setLabel('Masukkan Nama UCP').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(ucpInput));
            await interaction.showModal(modal);
        }

        if (customId === 'btn_reroll') {
            const modal = new ModalBuilder().setCustomId('modal_reroll').setTitle('Hapus Karakter Permanen');
            const charInput = new TextInputBuilder().setCustomId('char_name').setLabel('Nama Karakter yg dihapus').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(charInput));
            await interaction.showModal(modal);
        }

        if (customId === 'btn_open_ticket') {
            const thread = await interaction.channel.threads.create({
                name: `tiket-${interaction.user.username}`,
                autoArchiveDuration: 60,
                type: InteractionType.GuildPublicThread, // Simplified for this implementation
                reason: 'Laporan User',
            });
            await thread.send({ content: `Halo <@${interaction.user.id}>, silahkan jelaskan laporanmu di sini. Staff <@&${process.env.ADMIN_ROLE_ID}> akan segera membantu.` });
            await interaction.reply({ content: `Tiket dibalas di <#${thread.id}>`, ephemeral: true });
        }

        if (customId === 'btn_status') {
            try {
                const ucpRes = await db.query('SELECT `ucp`, `verifycode` FROM `playerucp` WHERE `DiscordID` = ?', [interaction.user.id]);
                if (ucpRes.length === 0) return interaction.reply({ content: '❌ Kamu belum terdaftar di sistem UCP kami.', ephemeral: true });

                const data = ucpRes[0];
                await interaction.reply({
                    content: `📋 **Status Akun Anda**\n\n👤 **UCP**: \`${data.ucp}\`\n🔢 **PIN/OTP**: ||${data.verifycode}||\n🔌 **Link Discord**: ✅ Terhubung\n\n*Jangan bagikan PIN ini ke siapapun!*`,
                    ephemeral: true
                });
            } catch (e) {
                await interaction.reply({ content: 'Database error.', ephemeral: true });
            }
        }

        if (customId === 'btn_change_pw') {
            const modal = new ModalBuilder().setCustomId('modal_changepw').setTitle('Ganti Password UCP');
            const pwInput = new TextInputBuilder().setCustomId('new_pw').setLabel('Password Baru').setStyle(TextInputStyle.Short).setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(pwInput));
            await interaction.showModal(modal);
        }
    }

    // Handling Modals
    if (interaction.type === InteractionType.ModalSubmit) {
        const { customId, fields, user } = interaction;

        if (customId === 'modal_register') {
            const ucpName = fields.getTextInputValue('ucp_name');
            // Basic validation
            if (ucpName.includes(' ')) return interaction.reply({ content: 'Nama UCP tidak boleh ada spasi!', ephemeral: true });

            try {
                const existing = await db.query('SELECT * FROM `playerucp` WHERE `ucp` = ?', [ucpName]);
                if (existing.length > 0) return interaction.reply({ content: 'Nama UCP tersebut sudah dipakai orang lain!', ephemeral: true });

                // One UCP per Discord check
                const discordCheck = await db.query('SELECT * FROM `playerucp` WHERE `DiscordID` = ?', [user.id]);
                if (discordCheck.length > 0) return interaction.reply({ content: `Kamu sudah punya UCP: **${discordCheck[0].ucp}**. Satu Discord hanya boleh 1 UCP.`, ephemeral: true });

                const verifyCode = Math.floor(100000 + Math.random() * 900000);
                await db.query('INSERT INTO `playerucp` (`ucp`, `verifycode`, `DiscordID`) VALUES (?, ?, ?)', [ucpName, verifyCode, user.id]);

                await user.send({ content: `✅ **PENDAFTARAN SUKSES!**\n\n👤 **UCP**: \`${ucpName}\`\n🔢 **PIN Login**: \`${verifyCode}\`\n\n*Masuk ke server dan gunakan PIN ini.*` })
                    .catch(() => { }); // Ignore if DM closed
                await interaction.reply({ content: '✅ Akun berhasil dibuat! Cek DM (Direct Message) kamu untuk melihat PIN.', ephemeral: true });
            } catch (e) {
                console.error(e);
                await interaction.reply({ content: 'Terjadi kesalahan database.', ephemeral: true });
            }
        }

        if (customId === 'modal_login') {
            const ucpName = fields.getTextInputValue('ucp_name');
            try {
                const results = await db.query('SELECT `verifycode` FROM `playerucp` WHERE `ucp` = ?', [ucpName]);
                if (results.length === 0) return interaction.reply({ content: 'UCP tidak ditemukan!', ephemeral: true });

                // Check if user owns this UCP (Security)
                const ownerRes = await db.query('SELECT `DiscordID` FROM `playerucp` WHERE `ucp` = ?', [ucpName]);
                if (ownerRes[0].DiscordID && ownerRes[0].DiscordID !== user.id)
                    return interaction.reply({ content: '❌ Ini bukan akun UCP milikmu!', ephemeral: true });

                await user.send({ content: `Informasi Login UCP: **${ucpName}**\nPIN/Kode kamu: **${results[0].verifycode}**` }).catch(() => { });
                await interaction.reply({ content: 'PIN telah dikirim ke DM kamu.', ephemeral: true });
            } catch (e) {
                if (e.code !== 10062 && e.code !== 40060) {
                    console.error('Interaction Error:', e);
                    try {
                        if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: 'Terjadi kesalahan sistem.', ephemeral: true });
                    } catch (err) { /* Ignore follow-up errors */ }
                }
            }
        }

        if (customId === 'modal_reroll') {
            const charName = fields.getTextInputValue('char_name');
            try {
                const results = await db.query('SELECT * FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                if (results.length === 0) return interaction.reply({ content: 'Karakter tidak ditemukan!', ephemeral: true });

                // Permission check: does this char belong to UCP linked to this Discord?
                const ownerUcp = await db.query('SELECT `ucp` FROM `playerucp` WHERE `DiscordID` = ?', [user.id]);
                if (ownerUcp.length === 0) return interaction.reply({ content: 'Kamu tidak punya UCP.', ephemeral: true });

                // Assuming player_characters has `Char_UCP` column
                const charUcpRes = await db.query('SELECT `Char_UCP` FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                if (charUcpRes.length > 0 && charUcpRes[0].Char_UCP !== ownerUcp[0].ucp) {
                    return interaction.reply({ content: '❌ Karakter ini bukan milik UCP kamu!', ephemeral: true });
                }

                await db.query('DELETE FROM `player_characters` WHERE `Char_Name` = ?', [charName]);
                await interaction.reply({ content: `✅ Karakter \`${charName}\` berhasil dihapus permanen via Reroll System.`, ephemeral: true });
            } catch (e) {
                await interaction.reply({ content: 'Gagal reroll. Pastikan nama benar.', ephemeral: true });
            }
        }

        if (customId === 'modal_changepw') {
            const newPw = fields.getTextInputValue('new_pw');
            try {
                // Determine UCP by Discord ID
                const ucpRes = await db.query('SELECT `ucp` FROM `playerucp` WHERE `DiscordID` = ?', [user.id]);
                if (ucpRes.length === 0) return interaction.reply({ content: 'Kamu belum punya akun UCP.', ephemeral: true });

                const ucpName = ucpRes[0].ucp;
                // Let's just update `verifycode` since that's what `modal_login` returns to user.
                await db.query('UPDATE `playerucp` SET `verifycode` = ? WHERE `ucp` = ?', [newPw, ucpName]); // Assuming numerical or string PIN
                await interaction.reply({ content: `✅ Password/PIN UCP **${ucpName}** berhasil diubah menjadi: \`${newPw}\``, ephemeral: true });
            } catch (e) {
                await interaction.reply({ content: 'Gagal update password.', ephemeral: true });
            }
        }
    }
});

client.login(process.env.DISCORD_TOKEN);
